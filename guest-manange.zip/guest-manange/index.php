<?php
/*
Plugin Name: Guest user manage 
Description: Add custom PHP, CSS, and JS 
Version: 1.0
Author: Subha
*/

if (!defined('ABSPATH')) exit;


add_action('init', 'cci_custom_php_function');
function cci_custom_php_function() {
    // Hook to wp_footer
add_action('wp_footer', 'cci_add_code_to_footer');

function cci_add_code_to_footer() {
    echo "Subhajyoti";
}
}

add_action('wp_enqueue_scripts', 'cci_enqueue_custom_styles');
function cci_enqueue_custom_styles() {
    wp_enqueue_style('cci-custom-style', plugin_dir_url(__FILE__) . 'css/style.css');
}

add_action('wp_enqueue_scripts', 'cci_enqueue_custom_scripts');
function cci_enqueue_custom_scripts() {
    wp_enqueue_script('cci-custom-script', plugin_dir_url(__FILE__) . 'js/script.js', array(), false, true);
}
